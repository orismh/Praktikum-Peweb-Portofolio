// Buat versi Mobile 
const menuToggle = document.getElementById('menu-toggle');
const navbar = document.getElementById('navbar');

if (menuToggle && navbar) {
    menuToggle.addEventListener('click', () => {
        navbar.classList.toggle('active');
    });
}

// Menutup menu secara otomatis untuk versi Mobile
const navLinks = document.querySelectorAll('nav a');
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        if (navbar.classList.contains('active')) {
            navbar.classList.remove('active');
        }
    });
});

// Pengiriman Formulir
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Pesan Terkirim');
        contactForm.reset();
    });
}

document.addEventListener('DOMContentLoaded', () => {

    // 1. NAVIGASI MOBILE (TOGGLE & AUTO CLOSE)
    const menuToggle = document.getElementById('menu-toggle');
    const navbar = document.getElementById('navbar');
    const navLinks = document.querySelectorAll('nav ul li a');

    if (menuToggle && navbar) {
        menuToggle.addEventListener('click', () => {
            navbar.classList.toggle('active');
        });
    }

    // Menutup menu mobile secara otomatis saat link diklik
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navbar.classList.remove('active');
        });
    });

    // 2. HIGHLIGHT NAVIGASI & HEADER SCROLL EFFECT
    const sections = document.querySelectorAll('section');
    const header = document.querySelector('header');

    window.addEventListener('scroll', () => {
        let currentSection = '';

        // Efek bayangan pada header saat di-scroll
        if (window.scrollY > 50) {
            header.classList.add('header-scrolled');
        } else {
            header.classList.remove('header-scrolled');
        }

        // Mendeteksi posisi section aktif saat ini
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 120;
            const sectionHeight = section.clientHeight;
            if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
                currentSection = section.getAttribute('id');
            }
        });

        // Memberikan class 'active' pada link navigasi yang sesuai
        navLinks.forEach(link => {
            link.classList.remove('active-link');
            if (link.getAttribute('href') === `#${currentSection}`) {
                link.classList.add('active-link');
            }
        });
    });

    // 3. EFEK TEKS KETIK OTOMATIS (TYPEWRITER EFFECT)
    const heroSpan = document.querySelector('.hero h1 span');
    if (heroSpan) {
        const roles = ['Seorang Pemula', 'Mahasiswa UNEJ', 'Game Enthusiast'];
        let roleIndex = 0;
        let charIndex = 0;
        let isDeleting = false;

        function typeEffect() {
            const currentRole = roles[roleIndex];

            if (isDeleting) {
                heroSpan.textContent = currentRole.substring(0, charIndex - 1);
                charIndex--;
            } else {
                heroSpan.textContent = currentRole.substring(0, charIndex + 1);
                charIndex++;
            }

            let typeSpeed = isDeleting ? 50 : 100;

            if (!isDeleting && charIndex === currentRole.length) {
                typeSpeed = 2000; // Tahan kata selama 2 detik
                isDeleting = true;
            } else if (isDeleting && charIndex === 0) {
                isDeleting = false;
                roleIndex = (roleIndex + 1) % roles.length;
                typeSpeed = 500;
            }

            setTimeout(typeEffect, typeSpeed);
        }

        typeEffect();
    }

    // 4. ANIMASI MUNCUL SAAT SCROLL (SCROLL REVEAL)
    const observerOptions = {
        threshold: 0.15
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('reveal-show');
            }
        });
    }, observerOptions);

    const revealElements = document.querySelectorAll('.project-card, .about, .contact-form');
    revealElements.forEach(el => {
        el.classList.add('reveal-hidden');
        observer.observe(el);
    });

    // 5. PENANGANAN FORM KONTAK & NOTIFIKASI DYNAMIS (TOAST)
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const nameInput = document.getElementById('fullName').value;

            // Tampilkan notifikasi toast interaktif
            showToast(`Terima kasih ${nameInput}, pesan Anda berhasil terkirim!`);
            contactForm.reset();
        });
    }

    // Fungsi membuat elemen DOM Toast secara dinamis
    function showToast(message) {
        const toast = document.createElement('div');
        toast.className = 'custom-toast';
        toast.innerText = message;
        document.body.appendChild(toast);

        setTimeout(() => toast.classList.add('show'), 100);

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3500);
    }
});